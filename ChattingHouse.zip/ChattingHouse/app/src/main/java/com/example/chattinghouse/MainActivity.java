package com.example.chattinghouse;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
TextView t1;
    Thread t;
    FirebaseAuth fba;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);

        fba=FirebaseAuth.getInstance();
        final FirebaseUser fbu=fba.getCurrentUser();
      t1=findViewById(R.id.t1);
      Typeface mycustomeFont=Typeface.createFromAsset(getAssets(),"fonts/LCALLIG.TTF");
      t1.setTypeface(mycustomeFont);

        t=new Thread() {
            @Override
            public void run() {
                try{
                    Thread.sleep(700);

                    if(fbu==null) {


                        Intent in = new Intent(MainActivity.this, Main2Activity.class);
                        startActivity(in);
                    }
                    else{
                        Intent in = new Intent(MainActivity.this, Main3Activity.class);
                        startActivity(in);
                    }
                    finish();


                }
                catch (Exception e){

                }

            }
        };
  t.start();


    }
}
