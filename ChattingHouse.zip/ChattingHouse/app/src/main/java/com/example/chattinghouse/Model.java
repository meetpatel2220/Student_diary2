package com.example.chattinghouse;

public class Model {

    public String name, cityname , email , passwordd,mobileno;


    public Model(String name, String cityname, String email, String passwordd, String mobileno) {
        this.name = name;
        this.cityname = cityname;
        this.email = email;
        this.passwordd = passwordd;
        this.mobileno = mobileno;
    }
    public Model(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasswordd() {
        return passwordd;
    }

    public void setPasswordd(String passwordd) {
        this.passwordd = passwordd;
    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String mobileno) {
        this.mobileno = mobileno;
    }
}
